module.exports = {
    PORT: 6200,
    mongoDBUrl: "mongodb+srv://ambika:ambika@123@cluster0.jy3tl.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    mongoDBOptions: {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useCreateIndex: true
    },
};
const express = require("express");
const router = express.Router();
const User = require("../../models/users");

router.post("/", function (request, response) {
    User(request.body).save()
    .then((data) => {
        return response.status(201).json(data);
    }).catch((error) => {
        return response.status(500).send(error);
    });
});

router.get("/", function (request, response) {
    const { timestamp } = request.query;
    User.find({
        createdAt: {
            $gte: new Date(timestamp)
        }
    })
    .sort({ createdAt: -1})
    .limit(5)
    .then((data) => {
        return response.status(200).json(data);
    }).catch((error) => {
        return response.status(500).json(error);
    })
})

router.get("/nearby", async function (request, response) {
    try {
        let { lat, long } = request.query;
        lat = parseInt(lat)
        long = parseInt(long)
        const result = await User.aggregate([{
            $geoNear: {
                near: {
                    type: "Point",
                    coordinates: [lat, long],
                    spherical: true,
                    "distanceField": "calcDistance"
                },
                "distanceField": "calcDistance"
            }
        }])
        return response.status(200).json(result);
    } catch (error) {
        console.log(error)
    }
})

router.patch("/", function (request, response) {
    const {
        type,
        value
    } = request.query;
    let query;
    if (type === "email") {
        query = {
            "email": value
        }
    } else if (type === "mobile") {
        query = {
            "mobile": value
        }
    } else {
        return response.status(400).json({
            error: "Bad Request",
            message: "invalid query in the url"
        });
    }
    User.findOneAndUpdate(query, {
        $set: request.body
    }, {
        new: true
    }).then((updatedData) => {
        return response.status(200).json(updatedData);
    }).catch((error) => {
        return response.status(500).send(error);
    });
});

router.delete("/", function (request, response) {
    const {
        type,
        value
    } = request.query;
    let query;
    if (type === "email") {
        query = {
            "email": value
        }
    } else if (type === "mobile") {
        query = {
            "mobile": value
        }
    } else {
        return response.status(400).json({
            error: "Bad Request",
            message: "invalid query in the url"
        });
    }
    User.remove(query)
        .then((success) => {
            return response.status(204).json(success);
        }).catch((error) => {
            return response.status(500).json(error);
        });
});

module.exports = router;
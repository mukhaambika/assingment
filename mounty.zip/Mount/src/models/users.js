const mongoose = require("mongoose");
const UserSchema = mongoose.Schema({
    name: { type: String, required: true }, 
    mobile: { type: String, unique: true, required: true }, 
    email: { type: String, unique: true, required: true }, 
    address: { 
        street: { type: String, required: true },
        locality: { type: String, required: true },
        city: { type: String, required: true },
        state: { type: String, required: true },
        pincode: { type: String, required: true },
    },
    location: {
        type: { 
            type: String, 
            required: true, 
            default: 'Point' 
        },
        coordinates: { type: [Number], required: true },
    }
},
{
    timestamps:true,
});
module.exports = mongoose.model('User', UserSchema);
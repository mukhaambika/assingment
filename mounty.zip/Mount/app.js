const express = require("express");
const mongoose = require("mongoose");
const users = require("./src/api/routes/users");
const server = express();
const config = require("./src/config/config");

server.use(express.json());
server.use("/v1.0.0/users", users);

/* MongoDB Connection */
mongoose.connect(config.mongoDBUrl, config.mongoDBOptions, (error, data) => {
  error ? console.log(`Failed to connect to MongoDB`) : console.log(`Connected to Database Successfully!!!`);;
})

/* To handle undefined routes */
server.use((req, res, next) => {
  const error = new Error('Route Not Found');
  error.status = 404;
  next(error);
});

/* To handle enexpected errors */
server.use((error, req, res, next) => {
  res.status(error.statusCode || 500);
  res.status(error.status || 500);
  res.json({
    error: {
      message: error.message
    }
  })
});

server.listen(config.PORT, () => {
  console.log(`App listening on port ${config.PORT}`);
});